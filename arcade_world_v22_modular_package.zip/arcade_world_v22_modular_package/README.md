# Arcade World v22 Modular Starter

This companion package mirrors the single-file build and gives you a starting point for splitting the project into modules.

Files:
- index.html
- styles.css
- app.js
- data/games.json
- data/events.json
- data/campaign.json

Recommended next step: move board/content definitions into JSON and progressively refactor app.js into modules.
